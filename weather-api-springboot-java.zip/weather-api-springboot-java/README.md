# Weather REST API Spring Boot & Java

Weather Report API implemented with Spring Boot and Java.
